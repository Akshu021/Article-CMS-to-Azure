from os import environ
from flask import Flask, request
import requests

from FlaskWebProject import app, LOG

# 🔑 Azure AD Config
CLIENT_ID = "8948f07e-294a-4da1-bc5b-5e838d79239d"     # Your Azure AD App ID
CLIENT_SECRET = "b5d16e2c-afcd-4cc9-81ed-6d2badde3d2a" # Your Azure App Secret
REDIRECT_URI = "https://localhost:5555/getAToken"      # Must match Azure App Registration
TENANT = "common"
TOKEN_ENDPOINT = f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/token"

GRAPH_ME_ENDPOINT = "https://graph.microsoft.com/v1.0/me"  # 👈 Graph API endpoint

# ✅ Home page with Microsoft Sign-in link
@app.route("/")
def index():
    auth_url = (
        f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/authorize"
        f"?client_id={CLIENT_ID}"
        f"&response_type=code"
        f"&redirect_uri={REDIRECT_URI}"
        f"&response_mode=query"
        f"&scope=openid profile offline_access User.Read"
        f"&state=12345"
        f"&prompt=consent"  # 👈 Always show consent page
    )

    return f"""
    <html>
      <head><title>Login</title></head>
      <body style="font-family: Arial; text-align: center; margin-top: 100px;">
        <h2>Welcome to Article CMS</h2>
        <a href="{auth_url}">
          <button style="padding: 10px 20px; font-size: 16px;">
            Sign in with Microsoft
          </button>
        </a>
      </body>
    </html>
    """

# ✅ Redirect endpoint: Exchange auth code for access token
@app.route("/getAToken")
def get_a_token():
    code = request.args.get("code")
    error = request.args.get("error")

    LOG.info("🔎 Entered /getAToken endpoint")
    LOG.info(f"Query params received: code={code}, error={error}")

    if error:
        return f"❌ Microsoft Login Error: {error}"

    if not code:
        return "❌ No authorization code returned from Microsoft."

    token_data = {
        "client_id": CLIENT_ID,
        "scope": "openid profile offline_access User.Read",
        "code": code,
        "redirect_uri": REDIRECT_URI,
        "grant_type": "authorization_code",
        "client_secret": CLIENT_SECRET,
    }

    try:
        token_response = requests.post(TOKEN_ENDPOINT, data=token_data)
        token_response.raise_for_status()
        token_json = token_response.json()
    except Exception as e:
        return f"❌ Exception while requesting token: {str(e)}<br>Response: {token_response.text}"

    access_token = token_json.get("access_token")
    refresh_token = token_json.get("refresh_token")

    if not access_token:
        return f"❌ No access token returned.<br>Response: {token_json}"

    LOG.info("✅ Successfully retrieved tokens from Microsoft")

    # 🔎 Call Microsoft Graph to get user info
    headers = {"Authorization": f"Bearer {access_token}"}
    try:
        graph_response = requests.get(GRAPH_ME_ENDPOINT, headers=headers)
        graph_response.raise_for_status()
        user_data = graph_response.json()
    except Exception as e:
        return f"❌ Failed to call Microsoft Graph API: {str(e)}<br>Response: {graph_response.text}"

    display_name = user_data.get("displayName", "N/A")
    email = user_data.get("mail") or user_data.get("userPrincipalName")

    return f"""
    <h2>✅ Login Successful!</h2>
    <p><b>Name:</b> {display_name}</p>
    <p><b>Email:</b> {email}</p>
    <p><b>Access Token:</b></p>
    <textarea rows="10" cols="100">{access_token}</textarea>
    <p><b>Refresh Token:</b></p>
    <textarea rows="5" cols="100">{refresh_token}</textarea>
    """

if __name__ == '__main__':
    HOST = environ.get('SERVER_HOST', 'localhost')
    try:
        PORT = int(environ.get('SERVER_PORT', '5555'))
    except ValueError:
        PORT = 5555
    app.run(HOST, PORT, ssl_context='adhoc')  # 👈 switch ssl_context=None if https gives trouble
