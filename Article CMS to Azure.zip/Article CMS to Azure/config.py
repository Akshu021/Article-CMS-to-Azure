import os

basedir = os.path.abspath(os.path.dirname(__file__))

class Config(object):
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'secret-key'

    # Azure Storage
    BLOB_ACCOUNT = os.environ.get('BLOB_ACCOUNT') or 'imagescms123'
    BLOB_STORAGE_KEY = os.environ.get('BLOB_STORAGE_KEY') or 'Mc3KMcyTevLXsebVdBt5mQoXH2hMmqpT6eF9K/ikb/zWyjPFmvIf8AV6DtbsKX/1Ci+FMeeMxxDE+AStxsPDTw=='
    BLOB_CONTAINER = os.environ.get('BLOB_CONTAINER') or 'images'

    # Azure SQL Database
    SQL_SERVER = os.environ.get('SQL_SERVER') or 'cmsserver56789.database.windows.net'
    SQL_DATABASE = os.environ.get('SQL_DATABASE') or 'cms'
    SQL_USER_NAME = os.environ.get('SQL_USER_NAME') or 'cmsadmin'
    SQL_PASSWORD = os.environ.get('SQL_PASSWORD') or 'Akanksha@21'
    SQLALCHEMY_DATABASE_URI = 'mssql+pyodbc://' + SQL_USER_NAME + '@' + SQL_SERVER + ':' + SQL_PASSWORD + '@' + SQL_SERVER + ':1433/' + SQL_DATABASE + '?driver=ODBC+Driver+17+for+SQL+Server'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Azure AD Authentication
    CLIENT_SECRET = os.environ.get('CLIENT_SECRET') or '9Tt8Q~F3Qb-q-hf~wF8I3-YLR8Zrtm0UMxwTjcVB'
    AUTHORITY = "https://login.microsoftonline.com/common"  # Multi-tenant
    CLIENT_ID = "8948f07e-294a-4da1-bc5b-5e838d79239d"
    REDIRECT_PATH = "/getAToken"  # Must match Azure AD app redirect URI
    SCOPE = ["User.Read"]  # Only read user profile
    SESSION_TYPE = "filesystem"  # Token cache stored in server-side session
