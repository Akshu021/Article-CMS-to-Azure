# Write-up: VM vs Azure App Service for CMS Deployment

### Analyze, choose, and justify the appropriate resource option for deploying the app.

For **both** a VM or App Service solution for the CMS app, we analyzed **costs, scalability, availability, and workflow**:

| Feature        | Azure Virtual Machine (VM) | Azure App Service |
|----------------|-----------------------------|--------------------|
| **Cost**       | Higher costs due to dedicated infrastructure. A VM requires paying for compute (vCPU, RAM), OS licensing, storage, and networking. Example: A Standard B2s VM (~2 vCPUs, 4 GB RAM) in East US costs around **$40–$50/month**, not including storage and bandwidth. | More cost-efficient for small to medium workloads. Pricing is tier-based (Free, Shared, Basic, Standard, Premium). A Basic B1 App Service plan (~1.75 GB RAM, 1 vCPU) costs around **$13/month**, with built-in scaling options. |
| **Scalability** | Scaling requires manual setup or VM Scale Sets. Vertical scaling is limited and horizontal scaling increases management complexity. | Built-in horizontal and vertical scaling with auto-scale rules. Scaling can be based on CPU, memory, or schedule, with minimal configuration. |
| **Availability** | Requires setup of Availability Sets or Zones, load balancers, and redundancy. This increases cost and management overhead. | High availability is built-in with 99.95%+ SLA. Microsoft manages redundancy, failover, and patching automatically. |
| **Workflow**   | Developer must manage OS updates, security patches, runtime installations, and deployment pipeline. More DevOps overhead. | Streamlined workflow with CI/CD integrations (GitHub, Azure DevOps). No OS management needed. Easy deployment and maintenance. |

---

### Choice and Justification

Based on the analysis, **Azure App Service** is the more appropriate solution for deploying the CMS app.  

- It is **more cost-efficient** for the expected workload compared to running a dedicated VM.  
- It provides **better scalability** through auto-scale without additional configuration.  
- It offers **high availability out of the box**, while VM requires more setup for redundancy.  
- The **workflow is simpler**, with seamless CI/CD deployment from GitHub.  

Therefore, Azure App Service is recommended as it provides cost efficiency, reliability, and ease of management, while reducing the infrastructure maintenance burden associated with VMs.  

---

### Assess app changes that would change your decision.

A move to a **VM-based solution** might be considered if the CMS app required:  
- **Custom OS-level configurations** or dependencies not supported by App Service.  
- **Specialized software installations** or background services that App Service cannot run.  
- **High-performance workloads** with strict hardware requirements where dedicated VMs offer better control.  

Unless such specialized needs arise, Azure App Service remains the most practical and efficient choice for this project.  
