# create_db.py
from FlaskWebProject import app, db
from FlaskWebProject.models import User

with app.app_context():
    db.create_all()
    if not User.query.filter_by(username='admin').first():
        u = User(username='admin')
        u.set_password('yourPassword')   # project uses werkzeug hash helpers; method likely exists
        db.session.add(u)
        db.session.commit()
        print("Admin user created: admin / yourPassword")
