from FlaskWebProject import db
from FlaskWebProject import models  # make sure models are imported so SQLAlchemy sees them

# Create all tables
db.create_all()
print("✅ Database tables created successfully!")
